import tkinter as tk
from tkinter import messagebox

# Configuration
NODE_WIDTH = 120
NODE_HEIGHT = 40
VERTICAL_GAP = 10
CANVAS_WIDTH = 300
CANVAS_HEIGHT = 500

class QueueVisualizer:
    def __init__(self, root):
        self.root = root
        self.root.title("Queue Visualizer") 
        self.root.geometry("350x680") 

        # Queue data: [Front, ..., Rear]
        self.queue = []

        # --- UI Setup ---
        
        # 1. Canvas at the top
        self.canvas = tk.Canvas(root, width=CANVAS_WIDTH, height=CANVAS_HEIGHT, bg='white', highlightthickness=0)
        self.canvas.pack(pady=10)

        # 2. Status label
        self.status_label = tk.Label(root, text="", fg="blue", font=("Arial", 11, "bold"))

        # 3. Control frame (Value input and Buttons)
        control_frame = tk.Frame(root)
        control_frame.pack(pady=5)

        # Push Value Label and Entry
        tk.Label(control_frame, text="Push Value:", font=("Arial", 11)).grid(row=0, column=0, padx=5)
        self.value_entry = tk.Entry(control_frame, width=15)
        self.value_entry.grid(row=0, column=1, padx=5)

        # Push/Pop Buttons
        push_btn = tk.Button(control_frame, text="Push", command=self.enqueue, width=8)
        push_btn.grid(row=0, column=2, padx=5)

        pop_btn = tk.Button(control_frame, text="Pop", command=self.dequeue, width=8)
        pop_btn.grid(row=1, column=2, padx=5, pady=5)

        # Finalize the Status Label position at the very bottom
        self.status_label.pack(side=tk.BOTTOM, pady=(0, 20))

        self.draw_queue()

    def draw_node(self, x, y, data):
        self.canvas.create_rectangle(x, y, x + NODE_WIDTH, y + NODE_HEIGHT, 
                                     fill="lightblue", outline="black", width=2)
        self.canvas.create_text(x + NODE_WIDTH/2, y + NODE_HEIGHT/2, 
                                text=str(data), font=("Arial", 12, "bold"))

    def draw_queue(self):
        self.canvas.delete("all")
        
        x = (CANVAS_WIDTH - NODE_WIDTH) // 2
        y_bottom = CANVAS_HEIGHT - NODE_HEIGHT - 20
        
        for i, val in enumerate(self.queue):
            current_y = y_bottom - (i * (NODE_HEIGHT + VERTICAL_GAP))
            
            if current_y < 10: 
                break
                
            self.draw_node(x, current_y, val)

            if i == len(self.queue) - 1:
                 self.canvas.create_text(x + NODE_WIDTH + 35, current_y + NODE_HEIGHT/2, 
                                    text="Top", fill="red", font=("Arial", 10, "bold"))

    def enqueue(self):
        val = self.value_entry.get().strip()
        if not val:
            messagebox.showwarning("Input Error", "Please enter a value.")
            return
        
        self.queue.append(val) 
        self.value_entry.delete(0, tk.END)
        self.status_label.config(text=f"Pushed {val} onto stack")
        self.draw_queue()

    def dequeue(self):
        if not self.queue:
            messagebox.showinfo("Empty", "Queue is empty!")
            return
        
        removed = self.queue.pop(0) 
        self.status_label.config(text=f"Popped {removed} from stack")
        self.draw_queue()

if __name__ == "__main__":
    root = tk.Tk()
    app = QueueVisualizer(root)
    root.mainloop()
