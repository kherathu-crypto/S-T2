import tkinter as tk
from tkinter import messagebox

# Constants for GUI Layout
NODE_WIDTH = 60
NODE_HEIGHT = 40
HORIZONTAL_GAP = 40
CANVAS_HEIGHT = 120
CANVAS_WIDTH = 900

# Task 1's classes and user defined functions
class Node:
    def __init__(self, data):
        self.data = data
        self.next = None

class SinglyLinkedList:
    def __init__(self):
        self.head = None

    def insert_at_index(self, data, index):
        new_node = Node(data)
        if index == 0:
            new_node.next = self.head
            self.head = new_node
            return True
        current = self.head
        prev = None
        count = 0
        while current and count < index:
            prev = current
            current = current.next
            count += 1
        if count == index:
            prev.next = new_node
            new_node.next = current
            return True
        return False

    def delete_value(self, val):
        current = self.head
        prev = None
        while current:
            if current.data == val:
                if prev:
                    prev.next = current.next
                else:
                    self.head = current.next
                return True
            prev = current
            current = current.next
        return False

    def to_list(self):
        arr = []
        current = self.head
        while current:
            arr.append(current.data)
            current = current.next
        return arr

# Required stuff from Task 2
class SinglyLinkedListVisualizer:
    def __init__(self, root):
        self.root = root
        self.root.title("Singly Linked List Visualizer")
        self.sll = SinglyLinkedList()

        # Canvas Setup
        self.canvas = tk.Canvas(root, width=CANVAS_WIDTH, height=CANVAS_HEIGHT, bg='white')
        self.canvas.pack(pady=20)

        # UI Controls Frame
        control_frame = tk.Frame(root)
        control_frame.pack()

        # Row 0: Insert controls
        tk.Label(control_frame, text="Insert Value:").grid(row=0, column=0)
        self.insert_value_entry = tk.Entry(control_frame, width=5)
        self.insert_value_entry.grid(row=0, column=1)

        tk.Label(control_frame, text="at Index:").grid(row=0, column=2)
        self.insert_index_entry = tk.Entry(control_frame, width=5)
        self.insert_index_entry.grid(row=0, column=3)

        insert_btn = tk.Button(control_frame, text="Insert", command=self.insert_node)
        insert_btn.grid(row=0, column=4, padx=10)

        # Row 1: Delete controls
        tk.Label(control_frame, text="Delete Value:").grid(row=1, column=0)
        self.delete_value_entry = tk.Entry(control_frame, width=5)
        self.delete_value_entry.grid(row=1, column=1)
        delete_btn = tk.Button(control_frame, text="Delete", command=self.delete_node)
        delete_btn.grid(row=1, column=4, padx=10)

        # Row 2: Search controls
        tk.Label(control_frame, text="Search Value:").grid(row=2, column=0)
        self.search_value_entry = tk.Entry(control_frame, width=5)
        self.search_value_entry.grid(row=2, column=1)
        search_btn = tk.Button(control_frame, text="Search", command=self.search_node)
        search_btn.grid(row=2, column=4, padx=10)
        self.status_label = tk.Label(root, text="", font=("Arial", 12), fg="blue")
        self.status_label.pack(pady=10)

        self.draw_list()

    def draw_list(self, highlight_index=None):
        self.canvas.delete("all")
        nodes = self.sll.to_list()
        x, y = 20, 40

        for i, val in enumerate(nodes):
            color = "yellow" if i == highlight_index else "lightgrey"
            outline = "red" if i == highlight_index else "black"
            
            # Draw rectangle for node
            self.canvas.create_rectangle(x, y, x + NODE_WIDTH, y + NODE_HEIGHT, 
                                         fill=color, outline=outline, width=2)
            # Draw value text
            self.canvas.create_text(x + NODE_WIDTH // 2, y + NODE_HEIGHT // 2, 
                                    text=str(val), font=("Arial", 16))

            # Draw Next Arrow (Single direction for SLL)
            if i < len(nodes) - 1:
                start_x = x + NODE_WIDTH
                start_y = y + NODE_HEIGHT // 2
                end_x = x + NODE_WIDTH + HORIZONTAL_GAP
                self.canvas.create_line(start_x, start_y, end_x, start_y, arrow=tk.LAST, width=2)

            x += NODE_WIDTH + HORIZONTAL_GAP

    def insert_node(self):
        try:
            val = int(self.insert_value_entry.get())
            idx = int(self.insert_index_entry.get())
            if self.sll.insert_at_index(val, idx):
                self.status_label.config(text=f"Inserted {val} at index {idx}")
                self.draw_list()
            else:
                messagebox.showerror("Error", "Index out of range")
        except ValueError:
            messagebox.showerror("Input Error", "Please enter valid integers.")

    def delete_node(self):
        try:
            val = int(self.delete_value_entry.get())
            if self.sll.delete_value(val):
                self.status_label.config(text=f"Deleted value {val} from the list")
                self.draw_list()
            else:
                messagebox.showinfo("Not Found", f"Value {val} not found.")
        except ValueError:
            messagebox.showerror("Input Error", "Please enter a valid integer.")

    def search_node(self):
        try:
            val = int(self.search_value_entry.get())
            nodes = self.sll.to_list()

            def highlight_next(i=0):
                if i < len(nodes):
                    self.draw_list(highlight_index=i)
                    if nodes[i] == val:
                        self.status_label.config(text=f"Value {val} found at index {i}")
                    else:
                        self.root.after(500, lambda: highlight_next(i + 1))
                else:
                    self.status_label.config(text=f"Value {val} not found in the list")
                    self.draw_list()
            highlight_next()
        except ValueError:
            messagebox.showerror("Input Error", "Please enter a valid integer.")

if __name__ == "__main__":
    root = tk.Tk()
    app = SinglyLinkedListVisualizer(root)    
    root.mainloop()
